﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ButterflyNetwork
{
    class Wiring
    {
        private float _x1;
        public float X1
        {
            get { return _x1; }
            set { _x1 = value; }
        }
        
        private float _y1;
        public float Y1
        {
            get { return _y1; }
            set { _y1 = value; }
        }

        private float _x2;
        public float X2
        {
            get { return _x2; }
            set { _x2 = value; }
        }

        private float _y2;
        public float Y2
        {
            get { return _y2; }
            set { _y2 = value; }
        }
        
        public Wiring()
        {

        }

        public Wiring(float x1, float y1, float x2, float y2)
        {
            this._x1 = x1;
            this._y1 = y1;
            this._x2 = x2;
            this._y2 = y2;
        }
        
        static public void Line(Panel f, float _x1, float _y1, float _x2, float _y2)
        {
            Graphics paper = f.CreateGraphics();
            Pen pen3 = new Pen(Color.Black);
            paper.DrawLine(pen3, _x1, _y1, _x2, _y2);
        }

    }
}
