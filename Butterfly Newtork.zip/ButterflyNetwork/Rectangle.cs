﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ButterflyNetwork
{
    public class Rectangle
    {
        
        private string id;
        private float _xp, _yp, _xs, _ys;
        
        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        public float Ys
        {
            get { return _ys; }
            set { _ys = value; }
        }

        public float Xs
        {
            get { return _xs; }
            set { _xs = value; }
        }

        public float Yp
        {
            get { return _yp; }
            set { _yp = value; }
        }

        public float Xp
        {
            get { return _xp; }
            set { _xp = value; }
        }
        
        public Rectangle()
        {
        }

        public Rectangle(float xp, float yp, float xs, float ys)
        {
            this._xp = xp;
            this._yp = yp;
            this._xs = xs;
            this._ys = ys;
        }

        public void Draw(Panel f)
        {
            Graphics paper = f.CreateGraphics();
            Pen pen3 = new Pen(Color.Black);
            paper.DrawRectangle(pen3, _xp, _yp, _xs, _ys);

        }
    }
}
