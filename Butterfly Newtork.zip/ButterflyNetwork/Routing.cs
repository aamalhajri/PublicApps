﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ButterflyNetwork
{
    class Routing
    {
        public Routing() { }

        float _lx1, _ly1, _rx1, _ry1;
        int t, sw, n, srows;

        public int SRows
        {
            get { return srows; }
            set { srows = value; }
        }

        public int N
        {
            get { return n; }
            set { n = value; }
        }

        public int Sw
        {
            get { return sw; }
            set { sw = value; }
        }

        public int T
        {
            get { return t; }
            set { t = value; }
        }
        public float Ry1
        {
            get { return _ry1; }
            set { _ry1 = value; }
        }

        public float Rx1
        {
            get { return _rx1; }
            set { _rx1 = value; }
        }

        public float Ly1
        {
            get { return _ly1; }
            set { _ly1 = value; }
        }

        public float Lx1
        {
            get { return _lx1; }
            set { _lx1 = value; }
        }




        public Routing(float Lx1, float Ly1, float Rx2, float Ry2)
        {
            this._lx1 = Lx1;
            this._ly1 = Ly1;
            this._rx1 = Rx1;
            this._ry1 = Ry1;
        }


        public void bitReverse(float lx1, float ly1, float rx1, float ly2)
        {

        }
    }
}
