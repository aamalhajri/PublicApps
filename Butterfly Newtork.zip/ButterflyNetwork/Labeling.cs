﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ButterflyNetwork
{
    public class Labeling
    {
        private int fontSize;
        private float _x, _y, _xDinc, _yDinc;
        private string _id;

        public int FontSize
        {
            get { return fontSize; }
            set { fontSize = value; }
        }

        public string Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public float YDinc
        {
            get { return _yDinc; }
            set { _yDinc = value; }
        }

        public float XDinc
        {
            get { return _xDinc; }
            set { _xDinc = value; }
        }

        public float Y
        {
            get { return _y; }
            set { _y = value; }
        }

        public float X
        {
            get { return _x; }
            set { _x = value; }
        }

        public Labeling()
        {
        }

        public Labeling(int FSZ, string ID, float Xx, float Yy, float XI, float YI)
        {
            this.fontSize = FSZ;
            this._id = ID;
            this._x = Xx;
            this._y = Yy;
            this._xDinc = XI;
            this._yDinc = YI;
        }

        public static void Write(Panel f, Brush Br, int fontSize, string _id, float _x, float _y, float _xDinc, float _yDinc)
        {
            Graphics paper2 = f.CreateGraphics();
            string drawString = _id;
            System.Drawing.Font ft = new System.Drawing.Font("Arial", fontSize);
            paper2.DrawString(drawString, ft, Br, _x + _xDinc, _y + _yDinc);
        }

        public static void Write(Panel f, int fontSize, string _id, float _x, float _y, float _xDinc, float _yDinc)
        {
            Graphics paper2 = f.CreateGraphics();
            Brush Br = new SolidBrush(Color.Black);
            string drawString = _id;
            System.Drawing.Font ft = new System.Drawing.Font("Arial", fontSize);
            paper2.DrawString(drawString, ft, Br, _x + _xDinc, _y + _yDinc);
        }
    }
}
