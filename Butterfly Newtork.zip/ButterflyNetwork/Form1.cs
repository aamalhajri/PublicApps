﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ButterflyNetwork
{
    public partial class frmButterfly : Form
    {
        List<Rectangle> Rs;
        List<Circle> Cs1, Cs2;
        private float alignC = 0;
        bool _showGraphic = false;
        private string Ch_id;
        private float Ch_x, Ch_y;
        
        public frmButterfly()
        {
            InitializeComponent();
        }

        public static float[,] x_left = null;
        public static float[,] y_left = null;
        public static float[,] x_right = null;
        public static float[,] y_right = null;

        public static float[,] x_leftS = null;
        public static float[,] y_leftS = null;

        public static string[,] Nbits = null;

        public int n, k, T, sw, SRows;


        //===============================================================================================

        private void btnDistNodes_Click(object sender, EventArgs e)
        {
            n = Convert.ToInt32(txtStages.Text);
            k = Convert.ToInt32(txtRadix.Text);
            T = Convert.ToInt32(System.Math.Pow(k, n));
            sw = n * Convert.ToInt32(Math.Pow(k, n - 1));
            SRows = Convert.ToInt32(Math.Pow(k, n - 1));
            
            panel1.Height = 200 + T * (20 + 8);

            if (txtRadix.Text == "")
            {
                MessageBox.Show("Enter the radix of the Switches");
                txtRadix.Focus();
            }
            else if (txtStages.Text == "")
            {
                MessageBox.Show("Enter the No. of Stages in the network");
                txtStages.Focus();
            }
            else if ((Convert.ToInt32(txtRadix.Text) % 2 == 1) && (Convert.ToInt32(txtStages.Text) % 2 == 1))
            {
                 MessageBox.Show("Invalid Input!! This permutation doesn't accept odd numbers for both radix and stage inputs. Try again");
                 txtRadix.Focus();
            }
            else
            {
                _showGraphic = !_showGraphic;
                panel1.Invalidate();
            }
        }

        //================================================ Button Wiring ========================================================

        private void txtStages_TextChanged(object sender, EventArgs e)
        {
            if (txtRadix.Text != "" || txtStages.Text != "")
            {
                btnDistNodes.Enabled = true;
                withChLabel.Enabled = true;
            }
            else
            {
                btnDistNodes.Enabled = false;
                withChLabel.Enabled = true;
            }
        }


        private void txtStages_GotFocus(object sender, EventArgs e)
        {
            txtStages.SelectAll();
        }

        // =======================================================================================================

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        // =======================================================================================================

        private void txtRadix_GotFocus(object sender, EventArgs e)
        {
            txtRadix.SelectAll();
        }

        public string ReplaceAt(string input, int index, char newChar)
        {
            if (input == null)
            {
                throw new ArgumentNullException("input");
            }
            char[] chars = input.ToCharArray();
            chars[index] = newChar;
            return new string(chars);
        }

        public string RevBits(string NB)
        {
            char[] cArray = NB.ToCharArray();
            string reverse = String.Empty;
            for (int i = cArray.Length - 1; i > -1; i--)
            {
                reverse += cArray[i];
            }
            return reverse;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            x_left = null;
            y_left = null;
            x_right = null;
            y_right = null;
            x_leftS = null;
            y_leftS = null;
            Nbits = null;
            n=0;
            k=0;
            T=0;
            sw = 0;
            SRows = 0;
            txtRadix.Text = "";
            txtStages.Text = "";
            btnDistNodes.Enabled = false;
            withChLabel.Checked = false;
            withChLabel.Enabled = false;
            panel1.Invalidate();
            txtRadix.Focus();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
                if (_showGraphic)
                {
                Rs = new List<Rectangle>();
                Cs1 = new List<Circle>();
                Cs2 = new List<Circle>();

                float _xp = 0;
                float RCdis = 0;

                if (n > 3)
                {
                    _xp = 450;
                    RCdis = 450;
                }
                else
                {
                    _xp = 550;
                    RCdis = 550;
                }
                float _yp = 50;
                float _xs = 20;
                float _ys = 20;

                float cx = _xp - 75;
                float cy = 0;

                if (k % 2 == 0)
                    //  cy = _yp + [[(k / 2 * 20) + (k / 2 - 1) * 8 + 4 ]] = alignC;
                    alignC = 14 * k - 4;
                else
                    //    cy = _yp + [[(k / 2 * 20) + (k / 2 * 8) + 10]] = alignC;
                    alignC = (k / 2 * 20) + (k / 2 * 8) + 10;

                //=================================================== Creating Terminals (Circles) ======================

                cy = 50;
                for (int h = 1; h <= k * SRows; h++)
                {
                    Circle C1 = new Circle();
                    Circle C2 = new Circle();

                    C1.Xp = cx;
                    C1.Yp = cy;
                    C1.Xs = _xs;
                    C1.Ys = _ys;

                    C2.Xp = cx;
                    C2.Yp = cy;
                    C2.Xs = _xs;
                    C2.Ys = _ys;

                    C1.Id = Convert.ToString(h - 1);
                    C2.Id = Convert.ToString(h - 1);

                    Cs1.Add(C1);
                    Cs2.Add(C2);
                    cy += 28;
                }

                //===================================================================================================================

                _yp = 50 + alignC - 15;

                double[] z = null;
                z = new double[sw];

                double[] frac = null;
                frac = new double[k + 1];
                double el = 10.0 * k / (k + 1);
                for (int ter = 0; ter < T; ter++)
                {
                    for (int p = 1; p <= k; p++)
                    {
                        frac[p] = el * p;
                    }
                }

                // =============================== Define line position arrays between terminals & switches ============================

                float[] rx1 = null;
                rx1 = new float[T + 1];

                float[] ry1 = null;
                ry1 = new float[T + 1];

                float[] rx2 = null;
                rx2 = new float[T + 1];

                float[] ry2 = null;
                ry2 = new float[T + 1];

                int g = 0;
                int yu = 0;

                // ================================= Define line position arrays between switches ======================================

                x_left = new float[T, n];
                y_left = new float[T, n];
                x_right = new float[T, n];
                y_right = new float[T, n];

                x_leftS = new float[T, n];
                y_leftS = new float[T, n];
                // ================================================= Creating Switches (Rectangles) ====================================================================

                int Tk = 0;

                for (int i = 0; i < n; i++)
                {
                    _yp = 50 + alignC - (float)(10.0 * k / 2.0);
                    Tk = 0;
                    for (int j = 0; j < SRows; j++)
                    {
                        Rectangle R = new Rectangle();

                        R.Xp = _xp;
                        R.Yp = _yp;
                        R.Xs = 25;
                        R.Ys = 10 * k; ;
                        R.Id = Convert.ToString(i) + "." + Convert.ToString(j);
                        Rs.Add(R);

                        // =========================================== Storing line positions between switches =================================

                        for (int f = 1; f <= k; f++)
                        {
                            if (i == 0)
                            {
                                x_right[Tk, i] = R.Xp + 25;
                                y_right[Tk, i] = R.Yp + (float)frac[f];
                            }
                            else if (i % n == (n - 1))
                            {
                                x_left[Tk, i - 1] = R.Xp;
                                y_left[Tk, i - 1] = R.Yp + (float)frac[f];
                                x_leftS[Tk, i - 1] = R.Xp;
                                y_leftS[Tk, i - 1] = R.Yp + (float)frac[f];
                            }
                            else
                            {
                                x_right[Tk, i] = R.Xp + 25;
                                y_right[Tk, i] = R.Yp + (float)frac[f];
                                x_left[Tk, i - 1] = R.Xp;
                                y_left[Tk, i - 1] = R.Yp + (float)frac[f];

                                x_leftS[Tk, i - 1] = R.Xp;
                                y_leftS[Tk, i - 1] = R.Yp + (float)frac[f];
                            }
                            Tk++;
                        }

                        // ==================================== Storing line positions between terminals & switches =============================

                        if (i % n == 0)
                        {
                            for (int a = 1; a <= k; a++)
                            {
                                rx1[g] = R.Xp;
                                ry1[g] = R.Yp + (float)frac[a];
                                g++;
                            }
                        }
                        else if (i % n == (n - 1))
                        {
                            for (int b = 1; b <= k; b++)
                            {
                                rx2[yu] = R.Xp + 25;
                                ry2[yu] = R.Yp + (float)frac[b];
                                yu++;
                            }
                        }
                        // ======================================================================================================================
                        _yp = _yp + 2 * alignC + 8;
                    }

                    RCdis = RCdis + 100;
                    _xp += 100;
                }

                float xpinc = 1;
                float ypinc = 3F;

                cx = RCdis - 20;
                foreach (Circle C2 in Cs2)              // Initilize the x-pos of output Terminals
                {
                    C2.Xp = cx;
                }

                float[] wx1 = null;
                wx1 = new float[T];

                float[] wy1 = null;
                wy1 = new float[T];

                int counterC = 0;
                foreach (Circle C1 in Cs1)
                {
                    wx1[counterC] = C1.Xp + 20;
                    wy1[counterC] = C1.Yp + 10;
                    counterC++;
                    C1.DrawC(panel1);                     // Draw the output Terminals
                    if (C1.Id.Length == 1)
                        Labeling.Write(panel1, 8, C1.Id, C1.Xp, C1.Yp, xpinc + 4, ypinc);
                    else if (C1.Id.Length >= 2)
                        Labeling.Write(panel1, 8, C1.Id, C1.Xp, C1.Yp, xpinc, ypinc);
                }

                float[] wx2 = null;
                wx2 = new float[T];

                float[] wy2 = null;
                wy2 = new float[T];

                int counterC2 = 0;

                foreach (Circle C2 in Cs2)
                {
                    wx2[counterC2] = C2.Xp;
                    wy2[counterC2] = C2.Yp + 10;
                    counterC2++;
                    C2.DrawC(panel1);
                    if (C2.Id.Length == 1)
                    {
                        Labeling.Write(panel1, 8, C2.Id, C2.Xp, C2.Yp, xpinc + 4, ypinc);
                    }
                    else if (C2.Id.Length >= 2)
                    {
                        Labeling.Write(panel1, 8, C2.Id, C2.Xp, C2.Yp, xpinc, ypinc);
                    }
                }

                // ======================================================================================================

                foreach (Rectangle R in Rs)
                {
                    R.Draw(panel1);
                    Labeling.Write(panel1, 8, R.Id, R.Xp, R.Yp, xpinc, ypinc + (2 * k));
                }

                for (int fi = 0; fi < T; fi++)
                {
                    Wiring.Line(panel1, wx1[fi], wy1[fi], rx1[fi], ry1[fi]);
                    Wiring.Line(panel1, wx2[fi], wy2[fi], rx2[fi], ry2[fi]);
                }

                 // ================================================ Routing [d(n-i) <--> di] ===============================================================

                Nbits = new string[T, n];

                string Term;
                Term = Convert.ToString(T, 2);
                for (int yn = 0; yn < n - 1; yn++)
                    for (int t = 0; t < T; t++)
                    {
                        Nbits[t, yn] = Convert.ToString(t, 2);
                        string concat = "";
                        if (Term.Length >= Nbits[t, yn].Length)
                        {
                            for (int il = 1; il <= (Term.Length - Nbits[t, yn].Length); il++)
                            {
                                concat = "0" + concat;
                            }
                            Nbits[t, yn] = concat + Nbits[t, yn];
                        }
                    }

                char dn, d0, d3;
                for (int mt = 0; mt < n - 1; mt++)
                    for (int root = 0; root < T; root++)
                    {
                        Nbits[root, mt] = RevBits(Nbits[root, mt]);

                        dn = Convert.ToChar(Nbits[root, mt].Substring((n - mt - 1), 1));
                        d0 = Convert.ToChar(Nbits[root, mt].Substring(0, 1));
                        d3 = dn;

                        Nbits[root, mt] = ReplaceAt(Nbits[root, mt], (n - mt - 1), d0);
                        Nbits[root, mt] = ReplaceAt(Nbits[root, mt], 0, d3);

                        Nbits[root, mt] = RevBits(Nbits[root, mt]);
                        int s1 = Convert.ToInt32(Nbits[root, mt], 2);
                        x_left[root, mt] = x_leftS[s1, mt];
                        y_left[root, mt] = y_leftS[s1, mt];
                        Ch_id = Convert.ToString(root) + "." + Convert.ToString(mt);

                        float factor_ch = ((y_left[root, mt] - y_right[root, mt]) / (x_left[root, mt] - x_right[root, mt]));
                        if (root % 2 == 0)
                            Ch_x = x_right[root, mt] + 2;
                        else
                            Ch_x = x_left[root, mt] -18;
                        if (factor_ch == 0)
                            Ch_y = y_right[root, mt] - 6;
                        else if (factor_ch > 0)
                            Ch_y = y_right[root, mt] + 3 * factor_ch;
                        else if (factor_ch < 0)
                            Ch_y = y_right[root, mt] + 10 * factor_ch;
                        
                        Wiring.Line(panel1, x_right[root, mt], y_right[root, mt], x_left[root, mt], y_left[root, mt]);
                        

                        // ==================================== Channel Labeling  =====================================

                        if (withChLabel.Checked == true)
                        {
                            Brush Br = new SolidBrush(Color.Red);
                            Labeling.Write(panel1, Br, 8, Ch_id, Ch_x, Ch_y, 0, 0);
                        }
                    }
                }
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            

        }
    }
}

// =====================================================================================================
